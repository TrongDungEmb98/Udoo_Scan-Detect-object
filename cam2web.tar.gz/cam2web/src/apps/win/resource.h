//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by cam2web.rc
//

#define ID_MAX                  156

#define IDS_APP_TITLE           103

#define IDD_ABOUTBOX            103
#define IDD_SETTINGS_BOX        112
#define IDD_ACCESS_RIGHTS_BOX   124
#define IDD_EDIT_USER_BOX       139
#define IDD_EDIT_REALM_BOX      144
#define IDM_ABOUT               104
#define IDM_EXIT                105
#define IDM_SETTINGS            111
#define IDM_ACCESS_RIGHTS       123
#define IDI_CAM2WEB             107
#define IDI_CAM2WEB_GREEN       122
#define IDI_CAM2WEB_ORANGE      130
#define IDI_CAM2WEB_RED         131
#define IDI_CAMERA_ACTIVE_BLUE  132
#define IDI_CAMERA_ACTIVE_GREEN 133
#define IDI_CAMERA_ACTIVE_ORANGE 134
#define IDI_CAMERA_ACTIVE_RED   135
#define IDI_SETTINGS            146
#define IDI_USER                149
#define IDI_ADMIN               150
#define IDI_ABOUT               151
#define IDI_ACCESS              152
#define IDI_FAMILY              153
#define IDI_PASSWORD            154
#define IDI_FOLDER              155
#define IDC_CAM2WEB             109
#define IDC_MYICON              2
#define IDC_JPEG_Q_EDIT         113
#define IDC_JPEG_Q_SPIN         114
#define IDC_MJPEG_RATE_EDIT     115
#define IDC_MJPEG_RATE_SPIN     116
#define IDC_HTTP_PORT_EDIT      117
#define IDC_HTTP_PORT_SPIN      118
#define IDC_CUSTOM_WEB_EDIT     119
#define IDC_CUSTOM_WEB_BUTTON   148
#define IDC_CAMERA_TITLE_EDIT   147
#define IDC_SYS_TRAY_CHECK      145
#define IDC_ICON_COLOR_COMBO    156
#define IDC_LINK_HOME_PAGE      120
#define IDC_LINK_EMAIL          121
#define IDC_AUTH_DOMAIN_EDIT    125
#define IDC_CHANGE_DOMAIN_BUTTON 126
#define IDC_VIEWERS_COMBO       127
#define IDC_CONFIGURATORS_COMBO 128
#define IDC_USERS_LIST_VIEW     129
#define IDC_ADD_USER_BUTTON     136
#define IDC_EDIT_USER_BUTTON    137
#define IDC_DELETE_USER_BUTTON  138
#define IDC_USER_NAME_EDIT      140
#define IDC_USER_ROLE_COMBO     141
#define IDC_PASSWORD_EDIT       142
#define IDC_RE_PASSWORD_EDIT    143
#ifndef IDC_STATIC
#define IDC_STATIC              -1
#endif
// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS

#define _APS_NO_MFC                 130
#define _APS_NEXT_RESOURCE_VALUE    129
#define _APS_NEXT_COMMAND_VALUE     32771
#define _APS_NEXT_CONTROL_VALUE     1000
#define _APS_NEXT_SYMED_VALUE       110
#endif
#endif
