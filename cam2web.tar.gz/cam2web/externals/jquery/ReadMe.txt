jQuery 1.11.1
jQuery Mobile 1.4.2
