The folder contains source code of Mongoose web server, used by the project.

Version as of 2017-02-06
Latest commit: d39969d1e6168ea373e07456c557909744e57ee2

https://github.com/cesanta/mongoose
