The folder contains build of the libjpeg-turbo library, MSVC 2013.

Version as of 2017-03-18
Latest commit: da2a27ef056a0179cbd80f9146e58b89403d9933

https://github.com/libjpeg-turbo/libjpeg-turbo
